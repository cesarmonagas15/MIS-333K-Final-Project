﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace fa23team33_finalproject.Migrations
{
    /// <inheritdoc />
    public partial class newbirth : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
